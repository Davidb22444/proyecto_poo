
package paquete.clase;
public class Proyecto {

    public static void main(String[] args) {
        System.out.println("te amo.com");
        
    }
}
