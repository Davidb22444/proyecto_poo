
package descomponernumerovector;


public class Descomponernumerovector {

   
    public static void main(String[] args) {
        
    }
    
}
