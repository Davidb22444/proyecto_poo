
package paquete;

public class clase {

    public static void main(String[] args) {
        
        String nombre;
        char Sexo;
        double salario;
        boolean transporte;
        int edad;
            
            
            nombre = "samuel";
            Sexo = 'm';
            salario = 1500000.25;
            transporte = true;
            edad= 20;
            
            
            System.out.println("este es mi nombre= "+nombre);
            System.out.println("este es mi sexo= "+Sexo);
            System.out.println("esta es mi salario= "+salario);
            System.out.println("transporte "+transporte);
            System.out.println("mi edad es= "+edad);
        
        
        
   
    }
    
}
