
package indiceposicionvalor;

import java.util.Scanner;

public class IndicePosicionValor {

   
    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);
        char volver;

        int[] vector = new int[10];

        do {
            // Limpiar pantalla (simulado con líneas en consola)
            for (int l = 0; l < 30; l++) System.out.println();

            // Objetivo del algoritmo
            System.out.print("Diseñe un algoritmo que llene un vector de 10 posiciones con un ciclo for, ");
            System.out.println("luego imprima con otro ciclo el vector mostrando el índice, la posición y el valor.\n");

            // Llenar el vector con valores aleatorios del 0 al 99
            for (int i = 0; i < 10; i++) {
                vector[i] = (int)(Math.random() * 100);
            }

            // Mostrar índice, posición y valor
            System.out.println("Contenido del vector:");
            for (int i = 0; i < 10; i++) {
                System.out.println("Índice: " + i + ". Posición: " + (i + 1) + ". Valor: " + vector[i]);
            }

            // Preguntar si desea repetir
            System.out.print("\nPara repetir digite <s>, para salir cualquier tecla: ");
            String input = scanner.nextLine();
            volver = input.isEmpty() ? 'n' : input.charAt(0);

        } while (volver == 's' || volver == 'S');

        scanner.close();
    }
}
    
    

