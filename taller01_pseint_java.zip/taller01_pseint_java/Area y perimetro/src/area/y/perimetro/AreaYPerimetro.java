
package area.y.perimetro;

import java.util.Scanner;


public class AreaYPerimetro {

    
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);

        int menu = 0;
        double ladoA = 0, ladoB = 0, ladoC = 0, radio = 0, area = 0, perimetro = 0;

        // Mostrar introducción
        System.out.print("Diseñe un algoritmo que muestre un menú para la selección (1. Triángulo, 2. Rectángulo y 3. Círculo); ");
        System.out.print("luego pida los datos necesarios para la solución y muestre en pantalla el nombre de la figura, su área ");
        System.out.print("en unidades cuadradas y su perímetro en unidades simples. Recuerde que no existen áreas o ");
        System.out.println("perímetros menores o iguales a cero.");

        // Mostrar menú
        System.out.println("\n---------- MENU ----------");
        System.out.println("1. Triángulo");
        System.out.println("2. Rectángulo");
        System.out.println("3. Círculo");
        System.out.print("Seleccione una opción del menú: ");
        menu = scanner.nextInt();

        switch (menu) {
            case 1: // Triángulo
                System.out.println("\n-------------- Triángulo ------------------");

                // Leer base
                System.out.print("Digite la base: ");
                ladoA = scanner.nextDouble();
                while (ladoA <= 0) {
                    System.out.println("\nRecuerde que la base de un triángulo no puede ser menor o igual a 0");
                    System.out.print("Digite nuevamente la base: ");
                    ladoA = scanner.nextDouble();
                }

                // Leer altura
                System.out.print("Digite la altura: ");
                ladoB = scanner.nextDouble();
                while (ladoB <= 0) {
                    System.out.println("\nRecuerde que la altura de un triángulo no puede ser menor o igual a 0");
                    System.out.print("Digite nuevamente la altura: ");
                    ladoB = scanner.nextDouble();
                }

                // Área y perímetro
                area = (ladoA * ladoB) / 2;
                ladoC = Math.sqrt(Math.pow(ladoA, 2) + Math.pow(ladoB, 2));
                perimetro = ladoA + ladoB + ladoC;

                // Mostrar resultados
                System.out.println("\nLa Figura es un:   Triángulo");
                System.out.println("Su área es:        " + area + " metros cuadrados");
                System.out.println("Su perímetro es:   " + perimetro + " metros");
                break;

            case 2: // Rectángulo
                System.out.println("\n-------------- Rectángulo ------------------");

                // Leer lados
                System.out.print("Digite el lado A: ");
                ladoA = scanner.nextDouble();
                System.out.print("Digite el lado B: ");
                ladoB = scanner.nextDouble();

                while (ladoA <= 0 || ladoB <= 0) {
                    System.out.println("\nRecuerde que los lados de un rectángulo no pueden ser menores o iguales a 0");
                    System.out.print("Digite nuevamente el lado A: ");
                    ladoA = scanner.nextDouble();
                    System.out.print("Digite nuevamente el lado B: ");
                    ladoB = scanner.nextDouble();
                }

                // Cálculos
                area = ladoA * ladoB;
                perimetro = 2 * ladoA + 2 * ladoB;

                // Mostrar resultados
                System.out.println("\nLa Figura es un:   Rectángulo");
                System.out.println("Su área es:        " + area + " metros cuadrados");
                System.out.println("Su perímetro es:   " + perimetro + " metros");
                break;

            case 3: // Círculo
                System.out.println("\n-------------- Círculo ------------------");

                // Leer radio
                System.out.print("Digite el radio: ");
                radio = scanner.nextDouble();
                while (radio <= 0) {
                    System.out.println("\nRecuerde que el radio no puede ser menor o igual a 0");
                    System.out.print("Digite nuevamente el radio: ");
                    radio = scanner.nextDouble();
                }

                // Cálculos
                area = Math.PI * Math.pow(radio, 2);
                perimetro = 2 * Math.PI * radio;

                // Mostrar resultados
                System.out.println("\nLa Figura es un:        Círculo");
                System.out.println("Su área es:             " + area + " metros cuadrados");
                System.out.println("Su circunferencia es:   " + perimetro + " metros");
                break;

            default:
                System.out.println("\nLa opción del menú no existe");
        }

        scanner.close();
    }
    }
    

