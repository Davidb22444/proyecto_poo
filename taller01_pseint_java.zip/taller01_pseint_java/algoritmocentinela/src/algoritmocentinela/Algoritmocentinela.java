
package algoritmocentinela;

import java.util.Scanner;


public class Algoritmocentinela {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char volver;

        do {
            // Limpiar pantalla no existe en consola Java, pero puedes simularlo con líneas en blanco.
            System.out.println("\n\n\n");

            // Objetivo del algoritmo
            System.out.println("");

            // Inicializar variables, arreglos, etc.
            volver = 's';

            // Entrada de datos
            System.out.println("");

            // Proceso

            // Salida de datos
            System.out.println("");

            // Entrada de datos: Volver al menú
            System.out.println();
            System.out.print("Para repetir digite < s >, para salir cualquier tecla: ");
            String input = scanner.nextLine();
            if (!input.isEmpty()) {
                volver = input.charAt(0);
            }

        } while (volver == 's');

        scanner.close();
    }
}
    
    

