
package paquete;
import java.util.Scanner;

public class clase {

    
    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);

        // Declarar variables
        String nombre = "";
        char sexo = ' ';
        int edad = 0;
        double salario = 0.0;
        boolean transporte = false;

        // Objetivo del algoritmo
        System.out.println("Diseñe un algoritmo que solicite su nombre, sexo, edad, salario");
        System.out.println("(incluyendo centavos), si tiene o no vehículo de transporte y lo muestre en pantalla.\n");

        // Entrada de datos
        System.out.print("Digite su nombre: ");
        nombre = scanner.nextLine();

        System.out.print("Digite su sexo (H,M): ");
        sexo = scanner.next().charAt(0);

        System.out.print("Digite su edad: ");
        edad = scanner.nextInt();

        System.out.print("Digite su salario (con centavos): ");
        salario = scanner.nextDouble();

        System.out.print("¿Tiene vehículo? (1 = Sí, 0 = No): ");
        int tieneVehiculo = scanner.nextInt(); // Leer como entero
        transporte = (tieneVehiculo == 1); // Convertir a booleano

        // Salida de datos
        System.out.println("\n    Su nombre es : " + nombre);
        System.out.println("        Usted es : " + sexo);
        System.out.println("     Usted tiene : " + edad + " años");
        System.out.println("      Usted gana : " + salario + " pesos");
        System.out.println("¿Tiene vehículo? : " + (transporte ? "Sí" : "No"));

        scanner.close();
    }
}
    
    

