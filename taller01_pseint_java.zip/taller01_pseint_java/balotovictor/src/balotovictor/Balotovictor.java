
package balotovictor;

import java.util.Random;
import java.util.Scanner;


public class Balotovictor {

    
    public static void main(String[] args) {
        // Declarar variables
        char volver;
        int i, j, aux;
        int[] baloto = new int[6];

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        do {
            aux = 0;

            // Objetivo del algoritmo
            System.out.print("Diseñe un programa que por teclado solicite una acción y que muestre 6 números ");
            System.out.println("aleatorios del 1 al 45 sin repetirse y organizados de menor a mayor (baloto).");

            // Ingreso de datos
            System.out.println();
            System.out.println("Presione ENTER para hallar los números del baloto: ");
            scanner.nextLine(); // Esperar tecla

            // Proceso: ingreso de datos sin repetir
            baloto[0] = random.nextInt(45) + 1;

            for (i = 1; i < 6; i++) {
                baloto[i] = random.nextInt(45) + 1;

                for (j = 0; j < i; j++) {
                    if (baloto[i] == baloto[j]) {
                        i--; // Repetido, se repite la posición
                        break;
                    }
                }
            }

            // Ordenar los números (burbuja)
            for (i = 0; i < 5; i++) {
                for (j = 0; j < 5; j++) {
                    if (baloto[j] > baloto[j + 1]) {
                        aux = baloto[j];
                        baloto[j] = baloto[j + 1];
                        baloto[j + 1] = aux;
                    }
                }
            }

            // Mostrar el resultado
            System.out.println("\nNúmeros del Baloto:");
            for (i = 0; i < 6; i++) {
                System.out.println(baloto[i]);
            }

            // Repetir el ejercicio
            System.out.println();
            System.out.print("Si desea volver digite (s), de lo contrario cualquier tecla: ");
            String input = scanner.nextLine();
            volver = input.isEmpty() ? 'n' : input.charAt(0);

            // Limpiar pantalla (no es posible directamente, así que se simula)
            System.out.println("\n\n\n");

        } while (volver == 's' || volver == 'S');

        scanner.close();
    }
}
    
   

