
package factotial;

import java.util.Scanner;


public class Factotial {

    
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        char volver;

        do {
            // Limpiar pantalla simulada (puedes implementar en consola si deseas)
            System.out.println("\n\n\n");

            // Objetivo del algoritmo
            System.out.println("Encuentre el factorial de un número del 0 al 12,");
            System.out.println("si lo supera, el factorial es infinito.");

            // Iniciar variables
            int factorial = 1;
            int cant = 0;

            // Entrada de datos
            System.out.print("\nIngrese el número factorial: ");
            cant = sc.nextInt();

            // Proceso y salida
            if (cant <= 12 && cant >= 0) {
                factorial = 1;
                for (int i = 1; i <= cant; i++) {
                    factorial *= i;
                }
                System.out.println("\nEl factorial de " + cant + " es: " + factorial);
            } else {
                System.out.println("\nEl factorial es infinito");
            }

            // Volver al menú
            System.out.print("\nPara repetir digite <s>, para salir cualquier tecla: ");
            volver = sc.next().toLowerCase().charAt(0);

        } while (volver == 's');

        sc.close();
    }
}
    
    

