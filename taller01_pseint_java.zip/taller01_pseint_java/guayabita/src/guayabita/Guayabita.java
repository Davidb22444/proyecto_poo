
package guayabita;

import java.util.Random;
import java.util.Scanner;



public class Guayabita {

     static Scanner scanner = new Scanner(System.in);
    static Random random = new Random();

    // Subproceso: Mostrar el dado según el número
    public static void mostrarDado(int num) {
        switch (num) {
            case 1:
                System.out.println("                                     ______");
                System.out.println("                                    |      |");
                System.out.println("                                    |   O  |");
                System.out.println("                                    |______|");
                break;
            case 2:
                System.out.println("                                     ______");
                System.out.println("                                    |O     |");
                System.out.println("                                    |      |");
                System.out.println("                                    |____O_|");
                break;
            case 3:
                System.out.println("                                     ______ ");
                System.out.println("                                    |O     |");
                System.out.println("                                    |   O  |");
                System.out.println("                                    |____O_|");
                break;
            case 4:
                System.out.println("                                     ______ ");
                System.out.println("                                    |O    O|");
                System.out.println("                                    |      |");
                System.out.println("                                    |O____O|");
                break;
            case 5:
                System.out.println("                                     ______ ");
                System.out.println("                                    |O    O|");
                System.out.println("                                    |  O   |");
                System.out.println("                                    |O____O|");
                break;
            case 6:
                System.out.println("                                     ______ ");
                System.out.println("                                    |O    O|");
                System.out.println("                                    |O    O|");
                System.out.println("                                    |O____O|");
                break;
            default:
                System.out.println(":P");
        }
    }

  
    public static void main(String[] args) {

int cant, pozo, lanzar1, lanzar2, apuesta;
        String[] jugadores;

        System.out.println("Ejercicio 10. Juego de la Guayabita");
        do {
            System.out.print("Digite la cantidad de jugadores (2 a 6): ");
            cant = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer
            if (cant > 6 || cant <= 1) {
                System.out.println("No pueden ser más de 6 jugadores o menos de 2.");
            }
        } while (cant > 6 || cant <= 1);

        // Leer nombres
        jugadores = new String[cant];
        for (int i = 0; i < cant; i++) {
            System.out.print("Nombre del jugador " + (i + 1) + ": ");
            jugadores[i] = scanner.nextLine();
        }

        // Inicializar pozo
        pozo = cant;

        while (pozo > 0) {
            for (int i = 0; i < cant && pozo > 0; i++) {
                System.out.println("____________________________________________________________________________");
                System.out.println("\n------------------ El acumulado del pozo es: " + pozo + " ------------------");

                System.out.println(jugadores[i] + ", presiona ENTER para tu primer lanzamiento...");
                scanner.nextLine();
                lanzar1 = random.nextInt(6) + 1;
                mostrarDado(lanzar1);

                if (lanzar1 == 1 || lanzar1 == 6) {
                    pozo++;
                    System.out.println("\nHAS PERDIDO, coloca una moneda en la apuesta.");
                } else {
                    do {
                        System.out.print("\nLa apuesta mínima es 1, y la máxima es " + pozo + ": ");
                        apuesta = scanner.nextInt();
                        scanner.nextLine(); // limpiar buffer
                    } while (apuesta < 1 || apuesta > pozo);

                    System.out.println(jugadores[i] + ", presiona ENTER para tu segundo lanzamiento...");
                    scanner.nextLine();
                    lanzar2 = random.nextInt(6) + 1;
                    mostrarDado(lanzar2);

                    if (lanzar2 > lanzar1) {
                        pozo -= apuesta;
                        System.out.println("HAS GANADO, sacas " + apuesta + " del pozo.");
                    } else {
                        pozo += apuesta;
                        System.out.println("HAS PERDIDO, colocas " + apuesta + " en el pozo.");
                    }
                }
            }
        }

        System.out.println("\n____________________________________________________________________________");
        System.out.println("---------- ¡FIN DEL JUEGO, YA NO HAY MÁS DINERO QUE APOSTAR! ----------\n");
    }
}
       
    
    

