
package par.e.imapar.vector;

import java.util.Scanner;

public class ParEImaparVector {

   
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char volver;

        int num1, num2, cont, i, menu, aux;
        int[] pares = new int[1000000];
        int[] impares = new int[1000000];
        boolean band1, band2;

        do {
            // Inicialización de variables
            menu = 0;
            num1 = 0;
            num2 = 0;
            cont = 0;
            aux = 0;
            band1 = true;
            band2 = true;

            // Objetivo
            System.out.print("Diseñe un programa que solicite 2 números por teclado, luego indique al usuario si desea la serie ");
            System.out.print("par o impar, después muestre en pantalla la serie par o impar ");
            System.out.println("según la elección desde el número menor hasta el mayor.\n");

            // Ingreso de datos
            System.out.print("Digite el primer número: ");
            num1 = scanner.nextInt();

            // Asegurar que num2 sea distinto y reordenar si es necesario
            do {
                System.out.print("Digite el segundo número: ");
                num2 = scanner.nextInt();

                if (num1 == num2) {
                    System.out.println("\nDigite nuevamente el segundo número, ya que no puede ser igual al primero.\n");
                } else if (num1 > num2) {
                    aux = num1;
                    num1 = num2;
                    num2 = aux;
                }

            } while (num1 == num2);

            // Contar cuántos elementos potencialmente puede haber
            cont = (num2 - num1 + 1) / 2 + 1;

            // Almacenar pares e impares en vectores
            int indexPar = 0;
            int indexImpar = 0;

            for (i = num1; i <= num2; i++) {
                if (i % 2 == 0) {
                    pares[indexPar] = i;
                    indexPar++;
                } else {
                    impares[indexImpar] = i;
                    indexImpar++;
                }
            }

            // Menú para seleccionar serie
            do {
                System.out.println("\n----- Series -----");
                System.out.println("1. Impar");
                System.out.println("2. Par\n");
                System.out.print("Digite una opción del menú (1 o 2), otra tecla para salir: ");

                if (scanner.hasNextInt()) {
                    menu = scanner.nextInt();

                    if (menu == 1) {
                        System.out.println("\nSerie Impar:");
                        for (i = 0; i < indexImpar; i++) {
                            System.out.print(impares[i] + " - ");
                        }
                        System.out.println();

                    } else if (menu == 2) {
                        System.out.println("\nSerie Par:");
                        for (i = 0; i < indexPar; i++) {
                            System.out.print(pares[i] + " - ");
                        }
                        System.out.println();
                    }
                } else {
                    menu = 0; // Salir si no es entero
                    scanner.next(); // Limpiar entrada inválida
                }

            } while (menu == 1 || menu == 2);

            // Preguntar si desea repetir
            System.out.print("\n¿Desea volver al ejercicio? (s para sí, otra tecla para salir): ");
            scanner.nextLine(); // Limpiar salto de línea
            String opcion = scanner.nextLine();
            volver = opcion.isEmpty() ? 'n' : opcion.charAt(0);

            System.out.println("\n\n");

        } while (volver == 's' || volver == 'S');

        scanner.close();
    }
}
    
    

